let erroresMueblesMasVotada = document.getElementById("erroresMueblesMasVotada");
let erroresOrdenarPor = document.getElementById("erroresOrdenarPor");
/**
 * Funcion que filtra los muebles por la longitud del titulo y las muestra en el orden de votos
 */
function mueblesMasVotadas(){
    let inputLongitud = document.getElementById("longitudTitulo");
    let longitud = inputLongitud.value;
    let mueblesResultado = [];
    vaciarDivErrores(erroresMueblesMasVotadas);
    let esLongitudCorrecta = validarLogitud(inputLongitud,erroresMueblesMasVotadas);

    if(esLongitudCorrecta){
        muebles.forEach(muebles => {
            if(muebles.titulo.length >= longitud){
                if(!mueblesResultado.includes(muebles)){
                    mueblesResultado.push(mebles);
                }
            }
        });
        mueblesResultado = mueblesResultado.sort(function(mueble1,mueble2){
            return mueble2.votos - mueble1.votos;
        });
        mostrarMueblesHTML(mueblesResultado);
    }
}
//funcion para ordenar los puebles por la cantidad de votos que tienen
function mueblesMejorValorada(){
    let inputTipo = document.getElementById("tipo");
    let tipo = inputTipo.value;
    let mueblesTipo = [];
    let mueblesResultado = [];
    vaciarDivErrores(erroresMueblesMasVotada);
    let esTipoCorrecto = validarTipo(inputTipo,erroresMueblesMasVotada);

    if(esTipoCorrecto){

        for (let i = 0; i < muebles.length; i++) {
            if(muebles[i].tipo.toUpperCase() === tipo.toUpperCase()){
                if(!mueblesTipo.includes(muebles[i])){
                    mueblesTipo.push(muebles[i]);
                }
            }
            
        }
        
        mueblesTipo = mueblesTipo.sort(function(mueble1,mueble2){
            return mueble2.votos - mueble1.votos;
        });

        mueblesResultado.push(mueblesTipo[0]) ;
    }

    mostrarPeliculasHTML(mueblesResultado);
}
//funcion para ordenar los muebles 
function ordenarPor(){
    let inputOrden = document.getElementById("orden");
    let orden = inputOrden.value;
    let mueblesOrdenadas = [];
    vaciarDivErrores(erroresOrdenarPor);
    let esOrdenCorrecto = validarOpcionSeleccionada(inputOrden,erroresOrdenarPor);

    if(esOrdenCorrecto){
        mueblesOrdenadas = muebles;
        if(orden === "titulo"){
            mueblesOrdenadas = mueblesOrdenadas.sort(function(mueble1,mueble2){
                if(mueble1.titulo.toLowerCase() > mueble2.titulo.toLowerCase()){
                    return 1;
                }else if(mueble1.titulo.toLowerCase() < mueble2.titulo.toLowerCase()){
                    return -1;
                }else{
                    return 0;
                }
            });
        }else if(orden === "tipo"){
            mueblesOrdenadas = mueblesOrdenadas.sort(function(mueble1,mueble2){
                if(mueble1.tipo.toLowerCase() > mueble2.tipo.toLowerCase()){
                    return 1;
                }else if(mueble1.tipo.toLowerCase() < mueble2.tipo.toLowerCase()){
                    return -1;
                }else{
                    return 0;
                }
            });
        }else if(orden === "marca"){
            mueblesOrdenadas = mueblesOrdenadas.sort(function(mueble1,mueble2){
                if(mueble1.marca.nombre.toLowerCase() > mueble2.marca.nombre.toLowerCase()){
                    return 1;
                }else if(mueble1.marca.nombre.toLowerCase() < mueble2.marca.nombre.toLowerCase()){
                    return -1;
                }else{
                    return 0;
                }
            });
        }else if(orden === "tamanio"){
            mueblesOrdenadas = mueblesOrdenadas.sort(function(mueble1,mueble2){
                if(mueble1.tamanio.nombre.toLowerCase() > mueble2.tamanio.nombre.toLowerCase()){
                    return 1;
                }else if(mueble1.tamanio.nombre.toLowerCase() < mueble2.tamanio.nombre.toLowerCase()){
                    return -1;
                }else{
                    return 0;
                }
            });
        }else if(orden === "votos"){
            mueblesOrdenadas = mueblesOrdenadas.sort(function(mueble1,mueble2){
                return mueble2.votos - mueble1.votos;
            });
        }else{
            mueblesOrdenadas = mueblesOrdenadas.sort(function(mueble1,mueble2){
                return mueble2.disvotos - mueble1.disvotos;
            });
        }
        
    }

    mostrarPeliculasHTML(mueblesOrdenadas);
}



//OBTENIENDO BOTONES
let botonMueblesMasVotadas = document.getElementById("botonMueblesMasVotadas");
let inputLongitud = document.getElementById("longitudTitulo");
let botonPeliculaMasVotada = document.getElementById("botonPeliMasVotada");
let botonOrdenarPor = document.getElementById("botonOrdenarPor");



//EVENTOS 
botonMueblesMasVotadas.addEventListener("click",mueblesMasVotadas);
inputLongitud.addEventListener("focus",focus);
inputLongitud.addEventListener("blur",blur);

botonMueblesMasVotada.addEventListener("click", mueblesMejorValorad);
botonOrdenarPor.addEventListener("click",ordenarPor);



document.addEventListener("DOMContentLoaded", function(event) {
});