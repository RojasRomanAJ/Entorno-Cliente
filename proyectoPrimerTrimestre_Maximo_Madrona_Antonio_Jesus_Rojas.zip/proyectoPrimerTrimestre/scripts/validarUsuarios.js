// crearemos el evento 
document.addEventListener('DOMContentLoaded', function(event){
 creacionSelectionMuebles('selectMuebles');
 creacionSelectionUsuarios('selectUsuarioComentario');
 creacionSelectionUsuarios('selectUsuario');
 creacionSelectionUsuarios('usuarioSimilar');
 creacionSelectionUsuarios('comentarioUsuario');
});



function votoComentario(){
 let mueblesId = parseInt(document.getElementById('selectMuebles').value);
 let usuarioId = parseInt(document.getElementById('selectUsuarioComentario').value);
 let votos = parseInt(document.getElementById('selectVotos').value);
 let opinion = document.getElementById('comentarioUsuario').value;

 let muebles = listaMuebles.find(x => x.id===mueblesId);
 let usuario = listaUsuarios.find(x => x.id===usuarioId);

 if(validarVotoComentario()){
     document.getElementById('comentarioUsuario').nextElementSibling.innerHTML = '';
     usuario.votarMueble(muebles, votos);
     usuario.addOpinion(muebles, opinion);
     mostrarMuebelesHTML(listaMuebles);
 } else{
     document.getElementById('comentarioUsuario').nextElementSibling.innerHTML = 'No puedes votar mas de una vez el mismo mueble';
 }
}

function validarVotoComentario(){
 let validacion = true;
 let muebleId = parseInt(document.getElementById('selectMuebles').value);
 let usuarioId = parseInt(document.getElementById('selectUsuarioComentario').value);

 let muebles = listaMuebles.find(x => x.id===muebleId);
 let usuario = listaUsuarios.find(x => x.id===usuarioId);
 let votosUsuario = usuario.votos;

 for (let i = 0; i < votosUsuario.length; i++) {
     if(votosUsuario[i].mueble===mueble){
         validacion = false;
     }
 }
 return validacion;
}

function busquedaMueblesVotadosUsuario(){
 let usuario = listaUsuarios.find(x => x.id===parseInt(document.getElementById('selectUsuario').value));
 let votados = [];
 for (let i = 0; i < usuario.votos.length; i++) {
     votados.push(usuario.votos[i].mueble);
 }
 mostrarMueblesHTML(votados);
}

function encontrarmueblesSimilaresFavUsu(){
 let usuario = listaUsuarios.find(x => x.id===parseInt(document.getElementById('usuarioSimilar').value));
 let mueblesSimilares = [];
 for (let i = 0; i < usuario.mueblesFavoritos.length; i++) {
     for (let k = 0; k < listamuebles.length; k++) {
         if(usuario.mueblesFavoritos[i].genero===listamuebles[k].genero&&
         usuario.mueblesFavoritos[i].plataforma===listamuebles[k].plataforma&&
         !mueblesSimilares.includes(listamuebles[k])){
             mueblesSimilares.push(listamuebles[k]);
         }
     }
 }
 mostrarMueblesHTML(mueblesSimilares);
}

function encontrarmueblesComentariosPorUsuario(){
 let usuario = listaUsuarios.find(x => x.id===parseInt(document.getElementById('usuarioEncComentario').value));
 let comentados = [];
 for (let i = 0; i < usuario.comentarios.length; i++) {
     comentados.push(usuario.comentarios[i].mueble);
 }
 mostrarMueblesHTML(comentados);
}

let enviarVoto = document.getElementById('enviarVoto');
 enviarVoto.addEventListener('click', function(event){
 event.preventDefault();
 votoComentario();
});

let busquedaVotosUsuario = document.getElementById('busquedaVotosUsuario');
busquedaVotosUsuario.addEventListener('click',function(event){
 event.preventDefault();
 busquedaMueblesVotadosUsuario();
});