
function tratarCadenasInput(cadena){
	let cadenaResultante = null;
	if(typeof(cadena) === 'string'){
		let cadenaTratada = cadena.trim().toUpperCase();
		cadenaTratada = cadenaTratada.replace(/\s{2,}/g,' ');
		if(cadenaTratada !== ''){
			cadenaResultante = cadenaTratada;
		}
	}
	return cadenaResultante;
}

function mostrarMueblesHTML(listaDeMuebles){
	let divMuebles  = document.getElementById('muebles');
	divMuebles.innerHTML = '';
	if(listaDeMuebeles.length === 0){
		divMuebles.innerHTML = '';
	}else{
		listaDeMuebles.forEach( muebele => mueble.mostrarMuebles(divMuebles));
	}
}

function mostrarMueblesHTMLGestion(listaDeMuebles){
	let divMuebles  = document.getElementById('mueblesGestion');
	divMuebles.innerHTML = '';
	if(listaDeMuebles.length === 0){
		divMuebles.innerHTML = '';
	}else{
		listaDeMuebles.forEach( mueble => mueble.mostrarMuebles(divMuebles));
	}
}

function incluirMuebleHTML(mueble){
	let divMuebles  = document.getElementById('mueblesCreados');
	mueble.mostrarMuebles(divMuebles);
}

function mostrarUno(mueble, id){
	let divMuebles  = document.getElementById(id);
	divMuebles.innerHTML = "";
	mueble.mostrarMuebles(divMuebles);
}

function creacionSelectionMuebles(id){
    let selection = document.getElementById(id);
    for (let i = 0; i < listaMuebles.length; i++) {
        let opcionNueva = document.createElement('option');
        opcionNueva.value = listaMuebles[i].id;
        opcionNueva.innerHTML = listaMuebles[i].marca;
        selection.append(opcionNueva);
    }
}

function creacionSelectionUsuarios(id){
    let selection = document.getElementById(id);
    for (let i = 0; i < listaUsuarios.length; i++) {
        let opcionNueva = document.createElement('option');
        opcionNueva.value = listaUsuarios[i].id;
        opcionNueva.innerHTML = listaUsuarios[i].nombre;
        selection.append(opcionNueva);
    }
}

//funciones para la pagina gestion 
function mostrarMueblesHTML(mueblesMostrar){
    let divMuebles  = document.getElementById("mueblesMostrar");
    divMuebles.innerHTML = "";
    if(mueblesMostrar.length === 0){
        divMuebles.innerHTML = "NO HAY MUEBLES QUE MOSTRAR";
    }else{
        mueblesMostrar.forEach( muebles => muebles.mostrarEnHTML(divMuebles));
    }
}