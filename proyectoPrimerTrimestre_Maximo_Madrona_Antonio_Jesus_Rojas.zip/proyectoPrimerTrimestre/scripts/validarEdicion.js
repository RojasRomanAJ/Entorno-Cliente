/** Creamos los eventos a los cuales les asociamos una función */
$(function(){
    crearSelectOption("selectTipo", "selectTamanio");
    $("#marca").keyup(validarMarca);
    $("#selectTamanio").on("select", validarTamanio);
    $("#precio").keyup(validarPrecio);
    $("#selectTipo").on("select", function(event){
        event.preventDefault();
        validarTipo();
    });

    $("#create").click(crearMueble);

    $("#formCrear").submit(function(event){
        event.preventDefault();
        validarFormulario();
    });
})

/** Función la cual crea en los select las option que creamos en los arrays */
function crearSelectOption(selectTipo , selectTamanio){
    let select = document.getElementById(selectTipo);
    let arrTipo = ['SILLA', 'SILLON', 'MESA', 'ARMARIO', 'DIVAN', 'BALDA']; // En el array declaramos todos los datos que vamos a añadir en el select
    let select2 = document.getElementById(selectTamanio);
    let arrTamanio = ['PEQUEÑO', 'MEDIANO', 'GRANDE'];

    /** Recorremos el array y lo añadimos al select */
    for(mueble of arrTipo){
        let option = document.createElement("option");
        option.value = mueble;
        option.innerHTML = mueble;
        select.appendChild(option);
    }

    for(mueble of arrTamanio){
        let option = document.createElement("option");
        option.value = mueble;
        option.innerHTML = mueble;
        select2.appendChild(option);
    }
}

/** Funcion la cual validamos el inputMarca en caso de que no se cumplan con los requisitos manda error */
function validarMarca(){
    let esCorrecto = true;
        let expMarca = /[A-ZÅÄÖ]$/;
        let inputMarca = $("#marca").val().trim();
        $("#marca").removeClass();
        $("#erroresMarca").empty();

        if (!expMarca.test(inputMarca)){
            esCorrecto = false;
            let spanError = $("<span>SOLO SE PERMITEN MAYÚSCULAS</span>");
            $("#erroresMarca").empty();
            $("#erroresMarca").append(spanError);
        } 
        
        if (inputMarca === undefined || inputMarca === ""){
                esCorrecto = false;
                let spanError = $("<p><span>EL CAMPO MARCA NO DEBE ESTAR VACÍO</span>");
                $("#erroresMarca").append(spanError);
        }

        if (esCorrecto){
            $("#marca").addClass("inputCorrecto");
        } else {
            $("#marca").addClass("inputErroneo");
        }
        return esCorrecto;
}

/** Funcion la cual validamos el selectTamanio en caso de que no se cumplan con los requisitos manda error */
function validarTamanio(){
    let esCorrecto = true;
    let selectTamanio= $("#selectTamanio").val().trim();
    if (selectTamanio === undefined || selectTamanio === ""){
        esCorrecto = false;
        let spanError = $("<span>EL CAMPO NO DEBE ESTAR VACÍO, POR FAVOR SELECCIONE UNA OPCIÓN</span>");
        $("#erroresTamanio").append(spanError);
    }

    if (esCorrecto){
        $("#selectTamanio").addClass("inputCorrecto");
    } else {
        $("#selectTamanio").addClass("inputErroneo");
    }

    return esCorrecto;
}

/** Funcion la cual validamos el inputPrecio en caso de que no se cumplan con los requisitos manda error */
function validarPrecio(){
    let esCorrecto = true;
        let expPrecio = /^[0-9]+([,]{0,})+[0-9]+[€]$/;
        let inputPrecio= $("#precio").val().trim();
        $("#precio").removeClass();
        $("#erroresPrecio").empty();

        if (!expPrecio.test(inputPrecio)){
            esCorrecto = false;
            let spanError = $("<span>SOLO SE PERMITEN NÚMEROS. PRECIO DEBE CONTENER EL SÍMBOLO € AL FINAL DEL PRECIO. EJ: 245€ ó 245,45€</span>");
            $("#erroresPrecio").append(spanError);
        } 
        
        if (inputPrecio === undefined || inputPrecio === ""){
                esCorrecto = false;
                let spanError = $("<p><span>EL CAMPO PRECIO NO DEBE ESTAR VACÍO</span>");
                $("#erroresPrecio").append(spanError);
        }

        if (esCorrecto){
            $("#precio").addClass("inputCorrecto");
            $("#erroresPrecio").empty();
        } else {
            $("#precio").addClass("inputErroneo");
        }
        return esCorrecto;
}

/** Funcion la cual validamos el selectTipo en caso de que no se cumplan con los requisitos manda error */
function validarTipo(){
    let esCorrecto = true;
    let selectTipo = $("#selectTipo").val().trim();
    $("#precio").removeClass();
    $("#erroresPrecio").empty();

    if (selectTipo === undefined || selectTipo === ""){
        esCorrecto = false;
        let spanError = $("<span>EL CAMPO NO DEBE ESTAR VACÍO, POR FAVOR SELECCIONE UNA OPCIÓN</span>");
        $("#erroresTipo").append(spanError);
    }

    if (esCorrecto){
        $("#selectTipo").addClass("inputCorrecto");
    } else {
        $("#selectTipo").addClass("inputErroneo");
    }

    return esCorrecto;
}

/** Funcion la cual busca en el array listaMuebles alguna coincidencia en caso de que no exista el mueble lo crea */
function crearMueble(){
    let esCorrecto = false;
    let inputMarca = $("#marca").val().trim();
    let selectTamanio = $("#selectTamanio").val();
    let inputPrecio = $("#precio").val().trim();
    let selectTipo = $("#selectTipo").val();
    let mueble = [];

    mueble = listaMuebles.find(mueble => mueble.marca !== inputMarca.value
                                && mueble.tamanio !== selectTamanio.value
                                && mueble.precio !== inputPrecio.value
                                && mueble.tipo !== selectTipo.value);

    if (mueble !== undefined){
        esCorrecto = true;
        mueble = new Muebles(mueble.id++, inputMarca, selectTamanio, inputPrecio, selectTipo);
        listaMuebles.push(mueble);
    }

    return esCorrecto;

}

/** Validamos el formulario antes de enviarlo */
function validarFormulario(){
    let esMarcaCorrecta = validarMarca();
    let esTamanioCorrecto = validarTamanio();
    let esPrecioCorrecto = validarPrecio();
    let esTipoCorrecto = validarTipo();
    let esCorrectoMueble = crearMueble();

    if (esMarcaCorrecta && esTamanioCorrecto && esPrecioCorrecto && esTipoCorrecto && esCorrectoMueble){
        alert("TODO ESTA CORRECTO");
        let form = document.getElementById("formCrear");
        form.submit();
    } else {
        alert("HAY ERRORES EN EL FORMULARIO");
    }
}