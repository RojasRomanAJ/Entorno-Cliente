
/** Asociamos los eventos para el documento que vamos a controlar */

document.addEventListener("DOMContentLoaded", function(){

    let selectTipo = document.getElementById("selectTipo");
    selectTipo.addEventListener("select", validarBusqueda);

    let selectTamanio = document.getElementById("selectTamanio");
    selectTamanio.addEventListener("select", validarBusqueda);

    let busqueda = document.getElementById("buscar");
    busqueda.addEventListener("click", obtenerMuebles);

    crearSelectOption("selectTipo", "selectTamanio");

    crearSelectMuebles("marca");

    let mueblesSimilar = document.getElementById("marca");
    mueblesSimilar.addEventListener("change", obtenerMueblesSimilares);

    let formulario = document.getElementById("busquedaTipoTamaño");
    formulario.addEventListener("submit", comprobarFormulario);

});

/** Función la cual crea en los select las option que creamos en los arrays */
function crearSelectOption(selectTipo , selectTamanio){
    let select = document.getElementById(selectTipo);
    let arrTipo = ['silla', 'sillon', 'mesa', 'armario', 'divan', 'balda']; // En el array declaramos todos los datos que vamos a añadir en el select
    let select2 = document.getElementById(selectTamanio);
    let arrTamanio = ['pequeño', 'mediano', 'grande'];

    /** Recorremos el array y lo añadimos al select */
    for(mueble of arrTipo){
        let option = document.createElement("option");
        option.value = mueble;
        option.innerHTML = mueble;
        select.appendChild(option);
    }

    for(mueble of arrTamanio){
        let option = document.createElement("option");
        option.value = mueble;
        option.innerHTML = mueble;
        select2.appendChild(option);
    }
}


/** Funcion en la que buscamos si existe o no el producto a buscar */
function obtenerMuebles(event){
    let esCorrecto = true;
    let selectTipo = document.getElementById("selectTipo");
    let tipoSeleccionado = selectTipo.value;
    let selectTamanio = document.getElementById("selectTamanio");
    let tamanioSeleccionado = selectTamanio.value;
    let ulResultadoBusqueda = document.getElementById("resultadoBusqueda");
    ulResultadoBusqueda.innerHTML = "";

    let muebleBuscado = listaMuebles.find(muebles => muebles.tipo === tipoSeleccionado
                                                        && muebles.tamanio === tamanioSeleccionado); /**En esta parte buscamos en la listaMuebles el tamaño 
                                                                                                        y el tipo que hemos elegido en los select anteriores
                                                                                                        y los guardamos en una variable */

    /** Si el tamaño y el tipo que hemos seleccionado son distinto a undefined o "" mostramos por pantalla los datos recogidos del array listaMuebles */
    if (muebleBuscado !== undefined && muebleBuscado !== ""){
        esCorrecto = true;
        let liMueble = document.createElement("li");
            liMueble.innerHTML = `(${muebleBuscado.tipo}-${muebleBuscado.tamanio}) marca: ${muebleBuscado.marca} - precio: ${muebleBuscado.precio}`;
            ulResultadoBusqueda.appendChild(liMueble);
    /** En caso de no existir el objeto en el array reportamos error de "que no existe el producto/no se encuentra disponible" */
    } else {
        esCorrecto = false;
        let liMueble = document.createElement("li");
        liMueble.innerHTML = "EL PRODUCTO NO SE ENCUENTRA DISPONIBLE";
        ulResultadoBusqueda.appendChild(liMueble);
    }

    return esCorrecto;
}

 /**Funcion que valida la búsqueda*/
function validarBusqueda(event){
    let esCorrecto = true;
    let selectTipo = document.getElementById("selectTipo");
    let valor = selectTipo.value;
    let listaErrores = document.getElementById("erroresTipo");
    let selectTamanio = document.getElementById("selectTamanio");
    let valor2 = selectTamanio.value;
    let listaErrores2 = document.getElementById("erroresTamanio");
    listaErrores.innerHTML = "";
    listaErrores2.innerHTML = "";
    selectTipo.classList.remove("inputErroneo");
    selectTipo.classList.remove("inputCorrecto");
    selectTamanio.classList.remove("inputCorrecto");
    selectTamanio.classList.remove("inputErroneo");

    /** Si el valor seleccionado en selectTipo es = "ninguna" muestra error*/
    if (valor === " ") {
        esCorrecto = false;
        let divError = document.createElement("div");
        divError.innerHTML = "DEBES ELEGIR UNA OPCIÓN VÁLIDA";
        listaErrores.appendChild(divError);
        selectTipo.classList.add("inputErroneo");
    } else {
        esCorrecto = true;
        selectTipo.classList.add("inputCorrecto");
    }

    /** Si el valor seleccionado en selectTamanio es = "ninguna" muestra error*/
    if (valor2 === " ") {
        esCorrecto = false;
        let divError = document.createElement("div");
        divError.innerHTML = "DEBES ELEGIR UNA OPCIÓN VÁLIDA";
        listaErrores2.appendChild(divError);
        selectTamanio.classList.add("inputErroneo");
    } else {
        esCorrecto = true;
        selectTamanio.classList.add("inputCorrecto");
    }

    return esCorrecto;
}
/** Función la cual crea en el select el nombre de los muebles que creamos en la listaMuebles */
function crearSelectMuebles(idSelectMueble){
    let select = document.getElementById(idSelectMueble); 
    for(mueble of listaMuebles){
        let option = document.createElement("option");
        option.value = mueble.id;
        option.innerHTML = mueble.marca;
        select.appendChild(option);
    }
}

/** Funcion la cual recorre listaMuebles y si encuentra uno similar lo muestra por pantalla */
function obtenerMueblesSimilares(event) {
    let selectMarca = document.getElementById("marca");
    let idMarcaSeleccionada = selectMarca.value;
    let ulMueblesSimilares = document.getElementById("muebles_similares");
    ulMueblesSimilares.innerHTML = "";
    let spanTipoMueble = document.getElementById("titulo_marca");
    spanTipoMueble.innerHTML = "";

    if (idMarcaSeleccionada !== ""){
        let mueblesMostrados = 0;
        let muebleSeleccionado = listaMuebles.find(muebles => muebles.id === parseInt(idMarcaSeleccionada));
        spanTipoMueble.innerHTML = `${muebleSeleccionado.marca} (${muebleSeleccionado.tipo}-${muebleSeleccionado.tamanio})`;

        let mueblesSimilares = listaMuebles
                                .filter(muebles => muebles.tipo !== muebleSeleccionado.tipo)
                                .filter(muebles => muebles.tamanio === muebleSeleccionado.tamanio)
                                .filter(muebles => muebles.id !== muebleSeleccionado.id)
        
        mueblesSimilares.forEach(function(muebleSimilar){
            let liMueble = document.createElement("li");
            liMueble.innerHTML = `${muebleSimilar.marca} (${muebleSimilar.tipo}-${muebleSimilar.tamanio})`;
            ulMueblesSimilares.appendChild(liMueble);
            mueblesMostrados++;
        });

        if (mueblesMostrados == 0){
            let liMueble = document.createElement("li");
            liMueble.innerHTML = "NO SE HAN ENCONTRADO MUEBLES SIMILARES";
            ulMueblesSimilares.appendChild(liMueble);
        }
    }
}

/** Comprobamos que todo esta correcto y en caso de ser asi enviamos el formulario */
function comprobarFormulario(event){
    let esFormularioCorrecto = false;
    event.preventDefault();
    let esTipoCorrecto = validarBusqueda(document.getElementById("selectTipo"));
    let esTamanioCorrecto = validarBusqueda(document.getElementById("selectTamanio"));

    if(esTipoCorrecto && esTamanioCorrecto){
        esFormularioCorrecto = true;
        let formulario = document.getElementById("buscar");
        event.preventDefault();
    }else {
        alert("ERROR EN EL FORMULARIO");
    }

    return esFormularioCorrecto;
}