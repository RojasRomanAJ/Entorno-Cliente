class Muebles {
    constructor(id, marca, tamanio, precio, tipo){
        this._id = id;
        this._marca = marca;
        this._tamanio = tamanio;
        this._precio = precio;
        this._tipo = tipo;
    }

    get id(){
        return this._id;
    }

    set id(id){
        this._id = id;
    }

    get marca(){
        return this._marca;
    }

    set marca(marca){
        this._marca = marca;
    }

    get tamanio(){
        return this._tamanio;
    }

    set tamanio(tamanio){
        this._tamanio = tamanio;
    }

    get precio(){
        return this._precio;
    }

    set precio(precio){
        this._precio = precio;
    }

    get tipo(){
        return this._tipo;
    }

    set tipo(tipo){
        this._tipo = tipo;
    }

    addMueble(mueble){
        if(mueble instanceof Muebles){
        this.mueble.push(mueble);
        }
    }

}
//creamos la clase usuario 
class Usuario{
    constructor(id, nombre){
        this._id = id;
        this._nombre = nombre;
        this.votos = [];
        this.comentarios = [];
    
    }

    get id(){
        return this._id; 
    }

    set id(id){
        this._id = id;
    }
    get nombre(){
        return this._nombre;
    }
    
    set nombre(nombre){
        this._nombre = nombre;
    }

    get votos(){
        return this._votos;
    }

    set votos(votos){
        this._votos = votos;
    }

    get comentarios(){
        return this._comentarios;
    }
    
    set comentarios(comentarios){
        this._comentarios = comentarios;
    }
    
    votarMueble(muebles,votos){
        let valoracion = new Votos(votos, this, muebles);
        muebles.addValoracion(valoracion.votos);
        this.votos.push(valoracion);
    }

    addOpinion(muebles, comentario){
        let opinion = new Comentario(comentario, this, muebles);
        muebles.addComentario(comentario);
        this.comentarios.push(opinion);
    }
   

}
//Creamos la clase votos
class Votos{
    constructor(votos, usuarios, muebles, id){
        this._votos = votos;
        this._usuarios = usuarios;
        this._muebles = muebles;
    }

    get votos(){
        return this._votos; 
    }

    set votos(votos){
        this._voto = votos; 
    }

    get usuarios(){
        return this._usuarios; 
    }

    set usuarios(usuarios){
        this._usuarios = usuarios;
    }

    get muebles(){
        return this._muebles; 
    }

    set muebles(muebles){
        this._muebles = muebles;
    }
}
//Creamos clase comentario

class Comentario{
    constructor(comentario, usuarios, muebles){
        this._comentario = comentario;
        this._usuarios = usuarios;
        this._muebles = muebles;
    }

    get comentario(){
        return this._comentario;
    }
    
    get usuarios(){
        return this._usuarios;
    }

    get muebles(){
        return this._muebles;
    }

    set comentario(comentario){
        this._comentario = comentario;
    }

    set usuario(usuarios){
        this._usuarios = usuarios;
    }

    set muebles(muebles){
        this._muebles = muebles;
    }
}

class Usuarios {
    constructor(nombre, apellidos, direccion, correo, usuario, password){
        this._nombre = nombre;
        this._apellidos = apellidos;
        this._direccion = direccion;
        this._correo = correo;
        this._usuario = usuario;
        this._password = password;
    }

    get nombre() {
        return this._nombre;
    }

    set nombre(nombre) {
        this._nombre = nombre;
    }

    get apellidos() {
        return this._apellidos;
    }

    set apellidos(apellidos) {
        this._apellidos = apellidos;
    }

    get direccion() {
        return this._direccion;
    }

    set direccion(direccion) {
        this._direccion = direccion;
    }

    get correo() {
        return this._correo;
    }

    set correo(correo) {
        this._correo = correo;
    }

    get usuario() {
        return this._usuario;
    }

    set usuario(usuario) {
        this._usuario = usuario;
    }

    get password() {
        return this._password;
    }

    set password(password) {
        this._password = password;
    }
}

class Voto{
    constructor(voto, usuario, mueble, id){
        this.voto = voto;
        this.usuario = usuario;
        this.mueble = mueble;
    }

    get voto(){
        return this._voto; 
    }

    set voto(voto){
        this._voto = voto; 
    }

    get usuario(){
        return this._usuario; 
    }

    set usuario(usuario){
        this._usuario = usuario;
    }

    get mueble(){
        return this._mueble; 
    }

    set mueble(mueble){
        this._mueble = mueble;
    }

    get id(){
        return this._id;
    }

    set id(id){
        this._id = id;
    }
}
